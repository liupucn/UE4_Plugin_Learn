#include "FHoGTest.h"
#include "DebugHelpers.hpp"

FHoGTest::FHoGTest(const cv::Mat& InTargetImage)
{
	TargetImage = InTargetImage.clone();
	detector = cv::ORB::create();
	matcher = new cv::BFMatcher(cv::NORM_HAMMING, true);
}

void FHoGTest::Work(const cv::Mat& InTestImage)
{
	std::vector<cv::KeyPoint> keypoints;
	cv::Mat descriptor;
	detector->detect(TargetImage, keypoints);
	detector->compute(TargetImage, keypoints, descriptor);

	cv::Mat OutImage;
	cv::drawKeypoints(TargetImage, keypoints, OutImage);
	std::string KeyPointsStr = "keypoints=";
	KeyPointsStr+= std::to_string(keypoints.size());
	cv::putText(OutImage, KeyPointsStr, cv::Point(10, 15), CV_FONT_HERSHEY_PLAIN, 1, CV_RGB(0, 0, 0), 1);
	cv::showAndSave("HoGTestImage keypoints", OutImage);
	cv::showAndSave("HoGTestImage descriptors", descriptor);

	std::vector<cv::Mat> descriptors(1);
	descriptors[0] = descriptor.clone();
	matcher->add(descriptors);
	matcher->train();

////////////////
	std::vector<cv::KeyPoint> keypointsTest;
	cv::Mat descriptorTest;
	detector->detect(InTestImage, keypointsTest);
	detector->compute(InTestImage, keypointsTest, descriptorTest);

	std::vector<cv::DMatch> matches;
	matcher->match(descriptorTest, matches);

	std::string KeyPointsStrTest = "matches=";
	KeyPointsStrTest += std::to_string(matches.size());
	cv::putText(InTestImage, KeyPointsStrTest, cv::Point(10, 15), CV_FONT_HERSHEY_PLAIN, 1, CV_RGB(0, 0, 0), 1);
	cv::showAndSave("InTestImage", InTestImage);
}
