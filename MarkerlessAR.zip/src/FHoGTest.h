#pragma once
#include <opencv2/opencv.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/xfeatures2d.hpp>

class FHoGTest
{
public:
	FHoGTest(const cv::Mat& InTargetImage);

	void Work(const cv::Mat& InTestImage);

private:
	cv::Mat TargetImage;
	cv::Ptr<cv::FeatureDetector> detector;
	cv::Ptr<cv::DescriptorMatcher>  matcher;
};

